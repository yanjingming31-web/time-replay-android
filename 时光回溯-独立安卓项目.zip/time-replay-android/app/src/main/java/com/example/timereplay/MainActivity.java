package com.example.timereplay;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 501;
    private LinearLayout root, list;
    private TextView status;
    private final int ink = Color.rgb(28, 38, 58);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,28,22,18); root.setBackgroundColor(Color.rgb(245,247,251));
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = new TextView(this); title.setText("时光回溯"); title.setTextSize(30); title.setTextColor(ink); title.setTypeface(null,1); root.addView(title);
        TextView sub = new TextView(this); sub.setText("轻量画面记录 · 本地保存 · 按时间回顾"); sub.setTextSize(14); sub.setTextColor(Color.GRAY); sub.setPadding(0,6,0,20); root.addView(sub);
        status = new TextView(this); status.setText("当前未开始记录。开始时，Android 会弹出屏幕采集授权窗口。"); status.setTextSize(15); status.setTextColor(ink); status.setPadding(16,18,16,18); status.setBackgroundColor(Color.WHITE); root.addView(status);
        Button start = button("开始记录（每 15 秒采集一张）"); start.setOnClickListener(v -> { MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); startActivityForResult(m.createScreenCaptureIntent(), REQUEST_CAPTURE); }); root.addView(start);
        Button stop = button("停止记录"); stop.setOnClickListener(v -> { Intent i=new Intent(this,CaptureService.class); i.setAction(CaptureService.ACTION_STOP); startService(i); status.setText("已发送停止指令。可以刷新下方记录。"); }); root.addView(stop);
        Button refresh = button("刷新今日回顾"); refresh.setOnClickListener(v -> refreshList()); root.addView(refresh);
        Button clean = button("删除全部已保存画面"); clean.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setMessage("确定永久删除本应用保存的全部画面吗？").setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{ File dir=getCaptureDir(); File[] fs=dir.listFiles(); if(fs!=null) for(File f:fs) f.delete(); refreshList(); }).show()); root.addView(clean);
        TextView note = new TextView(this); note.setText("重要说明：这是间隔截图，不是视频。未采集的瞬间无法恢复。Android 会显示屏幕采集提示；部分受保护应用可能显示黑屏。截图只保存在本机应用目录。请勿用于未经同意监视他人。"); note.setTextColor(Color.DKGRAY); note.setTextSize(13); note.setPadding(4,16,4,16); root.addView(note);
        TextView h = new TextView(this); h.setText("已保存画面（新到旧）"); h.setTextColor(ink); h.setTextSize(19); h.setTypeface(null,1); h.setPadding(0,12,0,8); root.addView(h);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list); refreshList();
    }
    private Button button(String text){ Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,7,0,7); b.setLayoutParams(p); return b; }
    private File getCaptureDir(){ File f=new File(getFilesDir(),"captures"); if(!f.exists()) f.mkdirs(); return f; }
    private void refreshList(){ if(list==null)return; list.removeAllViews(); File[] fs=getCaptureDir().listFiles((d,n)->n.endsWith(".jpg")); if(fs==null||fs.length==0){ TextView empty=new TextView(this); empty.setText("还没有画面。点击“开始记录”并完成系统授权后，保持记录服务运行。"); empty.setTextColor(Color.GRAY); empty.setPadding(8,8,8,20); list.addView(empty); return; }
        java.util.Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        int max=Math.min(fs.length,100); for(int n=0;n<max;n++){ File f=fs[n]; LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(8,8,8,8); row.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.setMargins(0,3,0,3); list.addView(row,rp); ImageView im=new ImageView(this); im.setImageURI(android.net.Uri.fromFile(f)); im.setScaleType(ImageView.ScaleType.CENTER_CROP); row.addView(im,new LinearLayout.LayoutParams(130,90)); TextView t=new TextView(this); t.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new Date(f.lastModified()))+"\n"+String.format(Locale.getDefault(),"%.0f KB",f.length()/1024.0)); t.setTextColor(ink); t.setPadding(12,0,0,0); row.addView(t,new LinearLayout.LayoutParams(0,-2,1)); row.setOnClickListener(v->{ Intent i=new Intent(this,ImageViewActivity.class); i.putExtra("path",f.getAbsolutePath()); startActivity(i); }); }
        status.setText("已保存 "+fs.length+" 张画面。记录仅保存在本机应用目录。");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==REQUEST_CAPTURE){ if(resultCode==RESULT_OK && data!=null){ Intent i=new Intent(this,CaptureService.class); i.putExtra("resultCode",resultCode); i.putExtra("data",data); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); status.setText("正在记录。请通过通知栏中的停止按钮或本页停止按钮结束。"); } else status.setText("你取消了屏幕采集授权，没有开始记录。"); } }
    @Override protected void onResume(){super.onResume(); if(list!=null)refreshList();}
}
